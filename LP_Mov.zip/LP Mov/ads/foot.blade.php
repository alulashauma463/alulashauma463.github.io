<!-- Default Statcounter code for wp rich
https://bizz137.my.id/, https://rykerzz137.my.id/ -->
<script type="text/javascript">
var sc_project=12951297; 
var sc_invisible=1; 
var sc_security="483b4887"; 
</script>
<script type="text/javascript"
src="https://www.statcounter.com/counter/counter.js"
async></script>
<noscript><div class="statcounter"><a title="Web Analytics"
href="https://statcounter.com/" target="_blank"><img
class="statcounter"
src="https://c.statcounter.com/12951297/0/483b4887/1/"
alt="Web Analytics"
referrerPolicy="no-referrer-when-downgrade"></a></div></noscript>
<!-- End of Statcounter Code --></body>