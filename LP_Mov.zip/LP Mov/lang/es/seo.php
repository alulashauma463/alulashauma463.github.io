<?php

return [
    'home_title'       => 'Transmitir películas y programas de televisión gratis',
    'home_description' => '¡Navega y mira todas tus películas y series en línea favoritas gratis!',

    'movie_title' => 'Mira :title Película completa en línea gratis',
    'tv_title'    => 'Mira :title HD Programas de TV gratis',
];
