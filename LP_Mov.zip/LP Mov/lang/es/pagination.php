<?php

return [
    'previous' => '&laquo; Anterior',
    'next'     => 'Siguiente &raquo;',
];
