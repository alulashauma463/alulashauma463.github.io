<?php

return [
    'home_title'       => 'Oqimsiz filmlar va seriallar',
    'home_description' => 'Barcha sevimli onlayn filmlaringizni va seriallaringizni bepul tomosha qiling va tomosha qiling!',

    'movie_title' => 'Tomosha qilish :title To\'liq film Onlayn',
    'tv_title'    => ':title HD bepul TV ko\'rsatuvlarni tomosha qiling',
];
