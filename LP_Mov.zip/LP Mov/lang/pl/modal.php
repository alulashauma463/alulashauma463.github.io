<?php

return [
    'active_your_account_free' => 'Aktywuj BEZPŁATNE konto!',
    'you_must_create'          => 'Musisz utworzyć konto, aby kontynuować oglądanie',
    'continue_watch'           => 'Kontynuuj oglądanie za DARMO ➞',
    'quick_sign_up'            => 'Szybka rejestracja!',
    'take_less_then'           => 'Rejestracja zajmuje mniej niż minutę, a następnie możesz korzystać z nieograniczonej liczby filmów i tytułów telewizyjnych.',
];
