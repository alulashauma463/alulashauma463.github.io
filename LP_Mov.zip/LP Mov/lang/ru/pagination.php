<?php

return [
    'previous' => '&laquo; Назад',
    'next'     => 'Вперёд &raquo;'
];
