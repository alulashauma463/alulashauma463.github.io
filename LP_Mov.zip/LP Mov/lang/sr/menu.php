<?php

return [
    'movies'         => 'Филмови',
    'popular'        => 'Популарно',
    'now_playing'    => 'Сада се приказује',
    'top_rated'      => 'Најбоље оцењено',
    'upcoming'       => 'Предстојећи',
    'tv_shows'       => 'Серије',
    'on_tv'          => 'На ТВ-у',
    'airing_today'   => 'Емитује се данас',
    'genres'         => 'Жанрови',
    'popular_people' => 'Популарне особе',
    'search'         => 'Претрага...',
];


