<?php

return [
    'previous' => '&laquo; Előző',
    'next'     => 'Következő &raquo;',
];
