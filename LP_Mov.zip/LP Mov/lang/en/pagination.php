<?php

return [
    'previous' => '&lsaquo; Prev',
    'next'     => 'Next &rsaquo;'
];
