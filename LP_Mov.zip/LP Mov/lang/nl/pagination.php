<?php

return [
    'previous' => '&laquo; Vorige',
    'next'     => 'Volgende &raquo;',
];
