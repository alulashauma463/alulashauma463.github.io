<?php

return [
    'movies'         => 'Film',
    'popular'        => 'Populær',
    'now_playing'    => 'Afspilles nu',
    'top_rated'      => 'Bedst bedømt',
    'upcoming'       => 'Kommende',
    'tv_shows'       => 'TV udsendelser',
    'on_tv'          => 'I TV',
    'airing_today'   => 'Bliver sendt i dag',
    'genres'         => 'Søgeord',
    'popular_people' => 'Populære mennesker',
    'search'         => 'Søg...',
];


