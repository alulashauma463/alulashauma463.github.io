<?php

return [
    'sign_in'             => 'Log ind',
    'email'               => 'E-mail',
    'password'            => 'Adgangskode',
    'well_never_share'    => 'Vi vil aldrig dele din e-mail med nogen anden.',
    'forgot_password'     => 'Glemt kodeord?',
    'or'                  => 'Eller',
    'create_free_account' => 'Opret gratis konto',

    'enter_email'      => 'Indtast e-mail',
    'reset_password'   => 'Nulstille kodeord',
    'enter_your_email' => 'Indtast din e-mail-adresse, så sender vi dig et link for at nulstille din adgangskode.',
    'back_to_sign_in'  => 'Tilbage til log ind',
    'loading'          => 'Indlæser...',
];
