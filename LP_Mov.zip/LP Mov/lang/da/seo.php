<?php

return [
    'home_title'       => 'Stream gratis film og tv-shows',
    'home_description' => 'Gennemse og se alle dine foretrukne online film og serier gratis!',

    'movie_title' => 'Se :title Fuld film online gratis',
    'tv_title'    => 'Se :title HD gratis tv-shows',
];
