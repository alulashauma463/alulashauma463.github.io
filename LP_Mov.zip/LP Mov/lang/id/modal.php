<?php

return [
    'active_your_account_free' => 'Aktifkan Akun GRATIS Anda!',
    'you_must_create'          => 'Anda harus membuat akun untuk terus menonton',
    'continue_watch'           => 'Nonton GRATIS ➞',
    'quick_sign_up'            => 'Daftar Cepat!',
    'take_less_then'           => 'Kurang dari 1 menit untuk Mendaftar, maka Anda dapat menikmati judul Film & TV Tanpa Batas.',
];
