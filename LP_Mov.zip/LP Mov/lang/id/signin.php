<?php

return [
    'sign_in'             => 'Login',
    'email'               => 'E-mail',
    'password'            => 'Kata sandi',
    'well_never_share'    => 'Kami tidak akan pernah membagikan email Anda dengan orang lain.',
    'forgot_password'     => 'Lupa kata sandi?',
    'or'                  => 'Atau',
    'create_free_account' => 'Membuat akun gratis',

    'enter_email'      => 'Masukkan E-mail',
    'reset_password'   => 'Setel Ulang Kata Sandi',
    'enter_your_email' => 'Masukkan alamat email Anda dan kami akan mengirimkan Anda tautan untuk mereset kata sandi Anda.',
    'back_to_sign_in'  => 'Kembali ke Login',
    'loading'          => 'Tunggu...',
];
