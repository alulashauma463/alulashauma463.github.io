<?php

return [
    'movies'         => 'Filmy',
    'popular'        => 'Oblíbené',
    'now_playing'    => 'Právě se hraje',
    'top_rated'      => 'Nejlépe hodnocené',
    'upcoming'       => 'Nadcházející',
    'tv_shows'       => 'Seriály',
    'on_tv'          => 'V televizi',
    'airing_today'   => 'Vysílá se dnes',
    'genres'         => 'Žánry',
    'popular_people' => 'Oblíbení lidé',
    'search'         => 'Vyhledávání...',
];



