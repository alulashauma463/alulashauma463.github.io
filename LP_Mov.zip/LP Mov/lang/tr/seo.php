<?php

return [
    'home_title'       => 'Stream Ücretsiz Filmler ve TV Şovları',
    'home_description' => 'Gözatın ve en sevdiğiniz tüm çevrimiçi filmleri ve dizileri ücretsiz izleyin!',

    'movie_title' => ':title Bedava Film İzle Full Streaming Online',
    'tv_title'    => ':title HD Ücretsiz TV Şovunu İzleyin',
];
