<?php

return [
    'previous' => '&laquo; Önceki',
    'next'     => 'Sonraki &raquo;',
];
