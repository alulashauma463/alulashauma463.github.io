<?php

return [
    'view_all'        => 'Xem Tất Cả',
    'subscribe_watch' => 'Theo Dõi để Xem | $0.00',
    'released'        => 'Phát Hành',
    'runtime'         => 'Thời Gian Chạy',
    'genre'           => 'Thể Loại',
    'stars'           => 'Ngôi Sao',
    'director'        => 'Giám đốc',
    'minutes'         => 'Phút',
    'by'              => 'bởi',
    'users'           => 'Người Dùng',
    'download'        => 'Tải xuống',
    'season'          => 'Mùa',
    'watch'           => 'Đồng hồ đeo tay',
    'episode'         => 'Tập',
    'movies'          => 'Phim',
    'know_for'        => 'Được biết đến',
    'birthday'        => 'Sinh nhật',
    'place_of_birth'  => 'Nơi Sinh',
    'also_know_as'    => 'Còn được Biết đến Như',
    'biography'       => 'Tiểu sử',
    'sign_in'         => 'Đăng Nhập',
    'register'        => 'Ghi Danh',

    'watch_now'       => 'Xem Bây Giờ',
];
