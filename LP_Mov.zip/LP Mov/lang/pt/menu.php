<?php

return [
    'movies'         => 'Filmes',
    'popular'        => 'Populares',
    'now_playing'    => 'Em Exibição',
    'top_rated'      => 'Melhor Pontuação',
    'upcoming'       => 'Brevemente',
    'tv_shows'       => 'Séries de TV',
    'on_tv'          => 'Na TV',
    'airing_today'   => 'Emitidos Hoje',
    'genres'         => 'Géneros',
    'popular_people' => 'Pessoas Famosas',
    'search'         => 'Procurar...',
];


