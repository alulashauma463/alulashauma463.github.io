<?php

return [
    'home_title'       => 'Transmiteți filme și emisiuni TV gratuite',
    'home_description' => 'Căutați și vizionați gratuit toate filmele și serialele preferate online!',

    'movie_title' => 'Urmărește :title Filmul complet online gratuit',
    'tv_title'    => 'Urmărește :title Emisiuni TV gratuite HD',
];
