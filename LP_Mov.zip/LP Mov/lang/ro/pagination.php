<?php

return [
    'previous' => '&laquo; Înapoi',
    'next'     => 'Înainte &raquo;',
];
