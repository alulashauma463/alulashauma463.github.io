<?php

return [
    'home_title'       => '流媒体电影和电视节目',
    'home_description' => '免费浏览和观看所有您喜爱的在线电影和系列',

    'movie_title' => '观看 :title 完整电影在线免费',
    'tv_title'    => '观看 :title 高清免费电视节目',
];
