<?php

return [
    'sign_in'             => 'Prihlásiť sa',
    'email'               => 'e-mail',
    'password'            => 'heslo',
    'well_never_share'    => 'Váš e-mail nikdy nebudeme zdieľať s nikým iným.',
    'forgot_password'     => 'Zabudol si heslo?',
    'or'                  => 'alebo',
    'create_free_account' => 'Vytvorte si bezplatný účet',

    'enter_email'      => 'Zadajte e-mail',
    'reset_password'   => 'Obnoviť heslo',
    'enter_your_email' => 'Zadajte svoju e-mailovú adresu a my vám pošleme odkaz na obnovenie hesla.',
    'back_to_sign_in'  => 'Späť na prihlásenie',
    'loading'          => 'počkať...',
];
