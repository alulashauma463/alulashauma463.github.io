<?php

return [
    'movies'         => 'Film',
    'popular'        => 'Popolare',
    'now_playing'    => 'Adesso In Onda',
    'top_rated'      => 'Più Votati',
    'upcoming'       => 'In Arrivo',
    'tv_shows'       => 'Serie TV',
    'on_tv'          => 'In TV',
    'airing_today'   => 'Oggi In Onda',
    'genres'         => 'Generi',
    'popular_people' => 'Persone',
    'search'         => 'Ricerca...',
];
