<?php

return require __DIR__ . "/../../config.php";