@extends('layouts')

@section('content')
<div style="height: 6em"></div>
 <div class="container mt-5">
   <section class="bl">
        @include($page)
   </section>
 </div>
@endsection